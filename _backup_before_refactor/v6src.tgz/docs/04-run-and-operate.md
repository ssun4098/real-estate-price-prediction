# 4. 실행과 운영

## 준비물

- **Docker Desktop** (설치 후 실행 상태여야 합니다)
- 정부 API 키 3종 (발급 방법은 [README.md](../README.md) 2장). 키가 없어도 저장된 예시 열람은 가능합니다.

## 처음 켜기 (5단계)

터미널(PowerShell)에서 프로젝트 폴더로 이동한 뒤 실행합니다.

1. **설정 파일 만들기**
   ```powershell
   Copy-Item .env.example .env
   notepad .env
   ```
2. **`.env`에 입력**
   - `MYSQL_ROOT_PASSWORD`, `MYSQL_PASSWORD`: 길고 추측하기 어려운 값을 직접 정합니다 (**필수**, 비어 있으면 시작되지 않음)
   - `VWORLD_API_KEY`, `DATA_GO_KR_API_KEY`, `JUSO_API_KEY`: 발급받은 키
3. **켜기**
   ```powershell
   docker compose up -d --build
   ```
   처음에는 몇 분 걸립니다.
4. **접속:** 브라우저에서 `http://127.0.0.1:4175/`
5. **끄기:** `docker compose down` (데이터는 남음)

## 자주 쓰는 명령

| 하고 싶은 일 | 명령 |
|---|---|
| 상태 확인 | `docker compose ps` |
| 서버 로그 보기 | `docker compose logs api` |
| 코드 수정 후 반영 | `docker compose up -d --build api` |
| 재시작 | `docker compose restart api` |
| **데이터까지 전부 삭제** | `docker compose down -v` (되돌릴 수 없음. 주의) |

## 설정(.env) 요약

| 항목 | 의미 |
|---|---|
| `MYSQL_*` | 데이터베이스 계정 정보 |
| `*_API_KEY` | 정부 사이트 이용 키 |
| `VWORLD_DOMAIN` | 브이월드에 등록한 서비스 주소. 접속 주소와 같아야 함 |
| `PUBLIC_PORT` | 접속 포트 (기본 4175) |
| `ALLOWED_HOSTS` | 접속 허용 주소 추가. 다른 PC에서 접속하게 하려면 필요 |
| `MODEL_ENTRYPOINT` | 학습 모델 지정. 지금은 비워 둠 |

`.env`는 비밀번호가 들어 있으므로 **다른 사람에게 공유하거나 올리지 않습니다.** (git 제외 설정 되어 있음)

## 보안상 기본 설정

- 웹은 **내 컴퓨터(127.0.0.1)에서만** 접속됩니다. 다른 기기에서 접속하게 하려면 의도적으로 설정을 바꿔야 합니다.
- 데이터베이스는 **외부에서 접속할 수 없습니다.** api 상자만 접근합니다.
- 서버 프로그램은 관리자 권한 없이, 파일을 수정할 수 없는 상태로 실행됩니다.

## 문제 해결

| 증상 | 확인할 것 |
|---|---|
| 시작할 때 `.env에 MYSQL_PASSWORD를 입력하세요` | `.env`의 두 비밀번호가 비어 있음 |
| 접속하면 "허용된 실행 주소로 접속하세요" | 주소창을 `127.0.0.1:4175` 또는 `localhost:4175`로. 다른 주소를 쓰려면 `ALLOWED_HOSTS`에 추가 |
| 화면은 뜨는데 조회가 안 됨 | API 키 입력·승인 상태, 브이월드 등록 주소 확인 → 수정 후 `docker compose up -d` |
| "다른 자료를 조회 중입니다" | 정상. 몇 초 뒤 다시 시도 |
| api가 계속 재시작됨 | `docker compose logs api` 로 원인 확인. 대부분 DB 비밀번호 불일치 |
| 포트 사용 중 | `.env`에 `PUBLIC_PORT=4176` 처럼 다른 번호 지정, `VWORLD_DOMAIN`도 맞춰 수정 |

## 예전 방식

`python V6.py`로 데이터베이스 없이 내 PC에서 단독 실행하는 방식도 남아 있습니다 (파일로 저장). 새 방식과 **저장 위치가 서로 다르므로** 예전 방식으로 저장한 분석은 새 방식에 자동으로 나타나지 않습니다.

다음: [5. 용어집과 앞으로의 계획](05-glossary.md)
