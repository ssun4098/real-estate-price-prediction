# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

개발사업성 분석 V6: a real-estate development feasibility tool. A prebuilt React dashboard (`web/V6.template.html`) talks to a Python backend that calls Korean public APIs (VWorld, data.go.kr, Juso, KOSIS, SGIS) and runs the financial analysis engine. UI text, errors and comments are mostly Korean; keep that.

## Two ways to run the backend

1. **Legacy local mode** — `python V6.py` → `backend/pf_server.py` (stdlib `ThreadingHTTPServer`), file/SQLite storage under `runtime/outputs/`. Needs only `shapely` + `pyproj`.
2. **FastAPI + MySQL service** — `app/` (layered), run via Docker. Same HTTP routes as the legacy server, so the built frontend works with both.

`backend/` is the shared domain layer for both. `pf_server.py`/`pf_persistence` stay as the legacy path (existing tests import them); new work goes in `app/`.

## Commands

```sh
# Docker stack (api + mysql); needs .env with MYSQL_ROOT_PASSWORD and MYSQL_PASSWORD
cp .env.example .env
docker compose up -d --build        # http://127.0.0.1:4175/
docker compose up -d --build api    # after changing app/ or models/ENTRYPOINT

# Legacy local server
python -m venv .venv && .venv/Scripts/python.exe -m pip install -r requirements.txt
.venv/Scripts/python.exe V6.py [--port 4176 --no-browser]

# Tests (unittest, no network/keys). Must use an interpreter with shapely/pyproj installed.
python scripts/run_tests.py
python -m unittest discover -s tests -p "test_engine.py"      # one file (set PYTHONPATH=backend;tests;.)
```

`tests/test_app_api.py` exercises `app/` against SQLite via `DATABASE_URL` and skips itself if FastAPI is not installed. There is no linter config. Frontend (`frontend/`) is rebuilt separately with Node (`npm ci && npm run build`, copy `dist/index.html` to `web/V6.template.html`); its `AGENTS.md` and `protected-runtime.json` mark protected runtime files that must not be edited without the authorize script — don't touch the frontend unless asked.

## Architecture of `app/`

Dependency direction is strict: `api → services → repositories → db`, with `backend/` (domain) and `ml/` used by services.

- Only `app/api` and `app/core/http.py|guard.py` may import FastAPI; only `app/repositories` and `app/db` (and the composition root) may import SQLAlchemy. `services/` imports neither — keep it that way.
- `app/container.py` is the sole composition root (settings → engine → repositories → services). Routers get it via `Depends(get_container)`.
- `app/__init__.py` puts `backend/` on `sys.path` because the engine modules use flat imports (`from pf_engine import ...`). `sys.path` order matters; don't add a top-level module that collides with `pf_*`.
- Run with `uvicorn app.main:create_app --factory` (no module-level `app`, so importing doesn't require DB settings).
- Errors: every route uses `SafeRoute`, which converts any exception to `{"error":{"code","message"}}` (`ValueError/KeyError/TypeError` → 400, `ApiError` keeps its status). Responses go through `SafeJSONResponse`/`SafeBytesResponse`, which refuse to send a body containing any configured API key or the DB password. Handlers return `SafeJSONResponse(...)` directly (not dicts) to avoid FastAPI re-serialising up-to-64MB documents.
- Request bodies are parsed by the `json_body` dependency (JSON content type, 64MB cap, NaN rejected). A Host/Origin middleware allows only `ALLOWED_HOSTS` (default `127.0.0.1:PORT`, `localhost:PORT`); changing the exposed host/port requires updating it.
- Access logging is disabled on purpose (URLs carry addresses and upstream keys).

### Storage

MySQL tables (`app/db/models.py`) hold documents as LONGTEXT JSON strings (preserves key order/numbers): `analysis_snapshots`, `portfolio_samples`, `app_settings`, and the land-trade cache (`land_complete/pages/errors`). Tables are created at startup with `create_all` — there are no migrations. `MySqlLandStore` subclasses `pf_land_store.LandStore` (SQLite) and keeps its interface/cache policy so `pf_api.Collector` is unchanged. Bundled read-only samples come from `samples/` (`default.json` names the default). `V6.html` is no longer written to disk; `PageService` renders it per request.

### Services worth knowing

- `SnapshotService.validate` never trusts client-computed results: it re-runs `validate_snapshot` + `export_snapshot`, and rejects any payload containing a configured secret.
- `PortfolioService` samples are frozen captures (`persistencePolicy=portfolio_frozen_v1`); reading one must not recompute it with the current engine. The default sample is an explicit pointer and is never silently replaced.
- `PublicDataService` wraps `pf_api.Collector` and allows at most 4 concurrent upstream lookups (429 `BUSY` otherwise).

### Trained model (not built yet)

`app/ml/base.py` defines the `Predictor` protocol; `ModelRegistry` loads `MODEL_ENTRYPOINT=module:Class` from `MODEL_DIR` (`./models`, mounted read-only). With no entrypoint the app starts normally, `/api/model/status` reports `not_configured`, and `/api/model/predict` returns 503 `MODEL_NOT_READY`. Model failures at load never block startup. Details in `models/README.md`. The analysis engine does not depend on the model.

## `backend/` (domain layer)

Flat modules prefixed `pf_`: `pf_engine` (analysis/cashflow/validation; `analyze`, `validate_snapshot`), `pf_api` (`Collector`: all upstream HTTP, caches, comparables; `ApiError`), `pf_survey` (site survey, parcel enrichment), `pf_land`/`pf_boundary`/`pf_regions` (land classification, parcel boundary allocation, region catalog), `pf_persistence` (export rules), `pf_config` (key loading). Standard library plus shapely/pyproj only — do not add dependencies here. Export policy: Geocoder-derived/real-time revenue data is stripped from saved snapshots and must be re-queried (`exportPolicy: v5-geocoder-requery`).

## Configuration

All config is environment variables (see `.env.example`); in Docker they come from `.env` via compose. `pf_config.load_environment` (used only by legacy `V6.py`) rejects unknown variable names in `.env`, so DB/model variables are read by `app/core/settings.py` straight from the environment. VWorld keys must match `VWORLD_DOMAIN`.
